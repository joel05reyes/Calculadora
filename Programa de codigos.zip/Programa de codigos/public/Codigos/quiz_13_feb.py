A=[1,3,2,8,4]
def f(A):
  n=len(A)
  m= n-1
  B=A[1:m]*2
  return(B)
print(f(A))