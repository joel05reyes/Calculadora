print('Programa calculador de promedio')
a= float(input("primera nota: "))
b= float(input("Segunda nota: "))
c= float(input("tercera nota: "))
# se retiro los exesivos return aplicados en cada anidación de if
def f(d1,d2,d3):
  if d1>d2:
    if d2>d3:
      res= (d1+d2)/2
    else:
      res= (d1+d3)/2
  else:
    if d1>d3:
      res= (d2+d1)/2
    else:
      res= (d2+d3)/2
  return (res)
prom = f(a,b,c)
print(prom)
