words=input("Escribir palabras separadas por ,: ")
def agregar_ing(words:str)->str:
    separate= words.split(",")
    ordenated=[]
    for word in separate:
        reducir =word.strip()
        a=len(reducir)
        if a >= 3:
            char=reducir[-3:]
            if char == 'ing':
                reducir = reducir+'ly'
            else:
                reducir = reducir+'ing'
        else:
            reducir
        ordenated.append(word)
    ordenated.sort()
    return ",".join(ordenated)
print(agregar_ing(words))

    

